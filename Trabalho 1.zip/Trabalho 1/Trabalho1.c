




//INTEGRANTES:
// 1. KAYANNE PROCÓPIO FERRAZ DE SOUZA
// 2. GIOVANNA SILVA CUSTODIO
//USAMOS CODEBLOCKS COMO IDE PARA RODAR O PROJETO




#include <stdio.h>

int elementoExiste(int vetor[], int tamanho, int elemento) {
    for (int i = 0; i < tamanho; i++) {
        if (vetor[i] == elemento) {
            return 1;
        }
    }
    return 0;
}
void criarVetor(int vetor[], int tamanho) {
    printf("Digite os elementos do vetor (separados por espaços):\n");
    for (int i = 0; i < tamanho; i++) {
        scanf("%d", &vetor[i]);
    }
}

void imprimirVetor(int vetor[], int tamanho) {
    printf("Vetor: ");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
}

void diferencaVetores(int vetorA[], int vetorB[], int resultado[], int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        resultado[i] = vetorB[i] - vetorA[i];
    }
}


int pertenceVetor(int vetor[], int tamanho, int elemento) {
    for (int i = 0; i < tamanho; i++) {
        if (vetor[i] == elemento) {
            return 1;
        }
    }
    return 0;
}

int contarRepetidos(int vetor[], int tamanho) {
    int contador = 0;
    for (int i = 0; i < tamanho; i++) {
        for (int j = i + 1; j < tamanho; j++) {
            if (vetor[i] == vetor[j]) {
                contador++;
                break;
            }
        }
    }
    return contador;
}



void calcularIntersecao(int A[], int tamanhoA, int B[], int tamanhoB, int resultado[], int *tamanhoResultado) {
    *tamanhoResultado = 0;

    for (int i = 0; i < tamanhoA; i++) {
        for (int j = 0; j < tamanhoB; j++) {
            if (A[i] == B[j]) {
                resultado[(*tamanhoResultado)++] = A[i];
            }
        }
    }
}

void calcularUniao(int A[], int tamanhoA, int B[], int tamanhoB, int resultado[], int *tamanhoResultado) {
    *tamanhoResultado = 0;

    // Adicionar elementos de A à união
    for (int i = 0; i < tamanhoA; i++) {
        resultado[(*tamanhoResultado)++] = A[i];
    }

    // Adicionar elementos de B à união que não estejam em A
    for (int i = 0; i < tamanhoB; i++) {
        if (!elementoExiste(resultado, *tamanhoResultado, B[i])) {
            resultado[(*tamanhoResultado)++] = B[i];
        }
    }
}


void calcularDiferenca(int A[], int B[], int resultado[], int tamanhoA) {
    int tamanhoResultado = 0;

    for (int i = 0; i < tamanhoA; i++) {
        if (!elementoExiste(B, tamanhoA, A[i])) {
            resultado[tamanhoResultado++] = A[i];
        }
    }

    printf("Diferença (A - B): { ");
    for (int i = 0; i < tamanhoResultado; i++) {
        printf("%d ", resultado[i]);
    }
    printf("}\n");
}



int main() {
    int tamanho;
    printf("Digite o tamanho dos vetores A e B: ");
    scanf("%d", &tamanho);

    int vetorA[tamanho];
    int vetorB[tamanho];
    int resultado[tamanho + tamanho];
    int tamanhoResultado = 0;

    printf("Criar e Inserir Vetor A:\n");
    criarVetor(vetorA, tamanho);

    printf("Criar e Inserir Vetor B:\n");
    criarVetor(vetorB, tamanho);

    int opcao, A,B;
    int elementoA, tamanhoB, tamanhoA;
    int elementoB;
    printf("Escolha a operacao a ser realizada:\n");
    printf("1. Diferenca A - B\n");
    printf("2. Diferenca (B - A)\n");
    printf("3. Interseccao (A e B)\n");
    printf("4. Uniao entre A e B ( A U B )\n");
    printf("5. Verificar se um elemento pertence ao Conjunto A\n");
    printf("6. Verificar se um elemento pertence ao Conjunto B\n");
    printf("7. Verificar elementos repetidos no Conjunto A\n");
    printf("8. Verificar elementos repetidos no Conjunto B\n");
    scanf("%d", &opcao);

    switch (opcao) {
        case 1:

            diferencaVetores(vetorA, vetorB, resultado, tamanho);
            printf("Resultado da Diferenca (A - B):\n");
            imprimirVetor(resultado, tamanho);

                    break;

        case 2:
            diferencaVetores(vetorA, vetorB, resultado, tamanho);
            printf("Resultado da Diferenca (B - A):\n");
            imprimirVetor(resultado, tamanho);
            break;
        case 3:


            calcularIntersecao(vetorA, tamanho, vetorB, tamanho, resultado, &tamanhoResultado);
            printf("Intersecao (A ∩ B): { ");
            imprimirVetor(resultado, tamanhoResultado);
             break;

        case 4:

            calcularUniao(vetorA, tamanho, vetorB, tamanho, resultado, &tamanhoResultado);
            printf("Uniao (A U B):  ");
            imprimirVetor(resultado, tamanhoResultado);
             break;
        case 5:

            printf("Digite o elemento a ser verificado no Conjunto A: ");
            scanf("%d", &elementoA);
            if (pertenceVetor(vetorA, tamanho, elementoA)) {
                printf("%d pertence ao Conjunto A.\n", elementoA);
            } else {
                printf("%d nao pertence ao Conjunto A.\n", elementoA);
            }
            break;
        case 6:

            printf("Digite o elemento a ser verificado no Conjunto B: ");
            scanf("%d", &elementoB);
            if (pertenceVetor(vetorB, tamanho, elementoB)) {
                printf("%d pertence ao Conjunto B.\n", elementoB);
            } else {
                printf("%d nao pertence ao Conjunto B.\n", elementoB);
            }
            break;
        case 7:
            printf("Quantidade de elementos repetidos no Conjunto A: %d\n", contarRepetidos(vetorA, tamanho));
            break;
        case 8:
            printf("Quantidade de elementos repetidos no Conjunto B: %d\n", contarRepetidos(vetorB, tamanho));
            break;
        default:
            printf("Opcao invalida.\n");
    }

    return 0;
}
