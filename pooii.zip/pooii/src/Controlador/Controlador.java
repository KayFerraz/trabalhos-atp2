package Controlador;

import Dados.LocadoraDeVeiculoDados;
import Modelo.Cliente;
import Modelo.Funcionario;
import Modelo.Locacao;
import Modelo.LocadoraDeVeiculo;
import Modelo.Seguro;
import Modelo.Veiculo;
import Modelo.VeiculoImportado;
import Modelo.VeiculoNacional;

public class Controlador {
    public LocadoraDeVeiculo get() {
        LocadoraDeVeiculo locadora = LocadoraDeVeiculoDados.get();
        
        return locadora;
    }
    
    public void addCliente(Cliente c){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        locadora.getClientes().add(c);

        LocadoraDeVeiculoDados.store(locadora);
    }

    public String dadosClientes(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosClientes();
    }
    
    public String dadosClienteVeiculo(int codigo){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosClienteVeiculo(codigo);
    }
    
    public String dadosClientesAtraso(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosClientesAtraso();
    }
    
    public void addVeiculoNacional(VeiculoNacional vn){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        locadora.getVeiculos().add(vn);

        LocadoraDeVeiculoDados.store(locadora);
    }
    
    public String dadosVeiculosNacionais(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosVeiculosNacionais();
    }
    
    public void addVeiculoImportado(VeiculoImportado vi){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        locadora.getVeiculos().add(vi);

        LocadoraDeVeiculoDados.store(locadora);
    }
    
    public String dadosVeiculosImportados(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosVeiculosImportados();
    }

    public void addFuncionario(Funcionario f){
        LocadoraDeVeiculo locadora = LocadoraDeVeiculoDados.get();

        locadora.getFuncionarios().add(f);

        LocadoraDeVeiculoDados.store(locadora);
    }
    
    public String dadosFuncionarios() {
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosFuncionarios();
    }

    public void addSeguro(Seguro s){
        LocadoraDeVeiculo locadora = LocadoraDeVeiculoDados.get();

        locadora.getSeguros().add(s);

        LocadoraDeVeiculoDados.store(locadora);
    }
    
    public void addLocacao(Locacao s){
        LocadoraDeVeiculo locadora = LocadoraDeVeiculoDados.get();

        locadora.getLocacoes().add(s);

        LocadoraDeVeiculoDados.store(locadora);
    }
    
    public String dadosSeguros() {
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosSeguros();
    }
    
    public String dadosVeiculos(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosVeiculos();
    }
    
    public String dadosVeiculosAlugar(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosVeiculosAlugar();
    }
    
    public String dadosVeiculosAlugado(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosVeiculosAlugado();
    }
    
    public String dadosVeiculosCategoria(String categoria){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosVeiculosCategoria(categoria);
    }
    
    public String dadosVeiculosAtrasados(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosVeiculosAtrasados();
    }
    
    public Cliente buscarCliente(int idCliente){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.buscarCliente(idCliente);
    }
    
    public Funcionario buscarFuncionario(int idFuncionario){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.buscarFuncionario(idFuncionario);
    }
    
    public Veiculo buscarVeiculo(int idVeiculo){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.buscarVeiculo(idVeiculo);
    }
    
    public String dadosLocacoes(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosLocacoes();
    }
    
    public String dadosLocacoesCliente(String nome){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosLocacoesCliente(nome);
    }
    
    public String dadosLocacoesMes(int mes){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosLocacoesMes(mes);
    }
    
    public String dadosLocacoesFinalizadas(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosLocacoesFinalizadas();
    }
    
    public String dadosLocacoesNaoFinalizadas(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosLocacoesNaoFinalizadas();
    }
    
    public String dadosLocacoesNaoFinalizadasNacional(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosLocacoesNaoFinalizadasNacional();
    }
    
    public String dadosLocacoesNaoFinalizadasImportado(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosLocacoesNaoFinalizadasImportado();
    }
    
    public String dadosLocacoesAtrasadas(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosLocacoesAtrasadas();
    }
    
    public String dadosTiposSeguros(){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.dadosTiposSeguros();
    }

    public Seguro buscarSeguro(int idSeguro){
        LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) LocadoraDeVeiculoDados.get();

        return locadora.buscarSeguro(idSeguro);
    }
}
