import Modelo.LocadoraDeVeiculo;

import Dados.LocadoraDeVeiculoDados;

public class Main {
    public static void main(String[] args) {
        LocadoraDeVeiculo locadoraDeVeiculo = new LocadoraDeVeiculo(
            "Locadora X",
            "Rua da Locadora X",
            "locadorax.com",
            "@locadorax"
        );

        LocadoraDeVeiculoDados.store(locadoraDeVeiculo);
    }
}

