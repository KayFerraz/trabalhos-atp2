package IU;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author T-Gamer
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        IUPrincipal principal = new IUPrincipal();
        principal.setVisible(true);
        principal.setTitle("Sistema de Locação de Veículos");
        principal.toFront();
    }
    
}
