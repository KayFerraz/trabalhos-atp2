package Dados;

import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;

import Modelo.LocadoraDeVeiculo;

public class LocadoraDeVeiculoDados {
    public static LocadoraDeVeiculo get() {
        try {
            ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream("./db.txt"));

            LocadoraDeVeiculo locadora = (LocadoraDeVeiculo) inputStream.readObject();

            inputStream.close();

            return locadora;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static void store(LocadoraDeVeiculo locadoraDeVeiculo) {
        try {
            ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("./db.txt"));

            outputStream.writeObject(locadoraDeVeiculo);

            outputStream.flush();
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
