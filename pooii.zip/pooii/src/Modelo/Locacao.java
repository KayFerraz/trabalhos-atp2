package Modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public final class Locacao implements Serializable {
    private int codigoLocacao;
    private Cliente codigoCliente;
    private Funcionario codigoFuncionario;
    private Veiculo codigoVeiculo;
    private LocalDate dataLocacao;
    private LocalDate dataDevolucao;
    private float valorTotal;
    private Pagamento formaPagamento;
    private ArrayList<Seguro> segurosContratados;
    private Boolean finalizada;

    public float calcularValorTotal() {
        long qtdDias = ChronoUnit.DAYS.between(this.dataLocacao, this.dataDevolucao);
        this.valorTotal = this.codigoVeiculo.calcularValorDiaria() * (float) qtdDias;

        if (possuiSeguro()) {
            for (Seguro s : this.segurosContratados) {
                this.valorTotal += s.getValor();
            }
        }

        return this.valorTotal;
    }
    
    public String toString(){
        String dados = "\nLOCAÇÃO\nCódigo da Locação: " + this.codigoLocacao
                + "\nCliente: [" + this.codigoCliente.getCodigoUsuario() + "] - " + this.codigoCliente.getNome()
                + "\nFuncionário: [" + this.codigoFuncionario.getCodigoUsuario() + "] - " + this.codigoFuncionario.getNome()
                + "\nVeículo: [" + this.codigoVeiculo.getCodigoVeiculo() + "] - " + this.codigoVeiculo.getNomeModelo()
                + "\nData de Locação: " +this.dataLocacao
                + "\nData de Devolução: " +this.dataDevolucao
                + "\nValor Total: " + this.valorTotal
                + "\nForma de Pagamento: " +this.formaPagamento.getTipoPagamento()
                + "\nSeguros: " + this.segurosContratados.toString()
                + "\nFinalizada: " + this.finalizada + "\n\n";
        return dados;
    }

    public Locacao(int codigoLocacao, Cliente codigoCliente, Funcionario codigoFuncionario, Veiculo codigoVeiculo, LocalDate dataLocacao, LocalDate dataDevolucao, Pagamento formaPagamento, ArrayList<Seguro> segurosContratados, Boolean finalizada) {
        this.codigoLocacao = codigoLocacao;
        this.codigoCliente = codigoCliente;
        this.codigoFuncionario = codigoFuncionario;
        this.codigoVeiculo = codigoVeiculo;
        this.dataLocacao = dataLocacao;
        this.dataDevolucao = dataDevolucao;
        this.formaPagamento = formaPagamento;
        this.segurosContratados = segurosContratados;
        this.finalizada = finalizada;
        this.valorTotal = this.calcularValorTotal();
    }

    public Boolean possuiSeguro() {
        if (this.segurosContratados != null) {
            return true;
        }

        return false;
    }

    public int getCodigoLocacao() {
        return codigoLocacao;
    }

    public void setCodigoLocacao(int codigoLocacao) {
        this.codigoLocacao = codigoLocacao;
    }

    public Cliente getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(Cliente codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public Funcionario getCodigoFuncionario() {
        return codigoFuncionario;
    }

    public void setCodigoFuncionario(Funcionario codigoFuncionario) {
        this.codigoFuncionario = codigoFuncionario;
    }

    public Veiculo getCodigoVeiculo() {
        return codigoVeiculo;
    }

    public void setCodigoVeiculo(Veiculo codigoVeiculo) {
        this.codigoVeiculo = codigoVeiculo;
    }

    public LocalDate getDataLocacao() {
        return dataLocacao;
    }

    public void setDataLocacao(LocalDate dataLocacao) {
        this.dataLocacao = dataLocacao;
    }

    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(LocalDate dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public float getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    public Pagamento getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(Pagamento formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public ArrayList<Seguro> getSegurosContratados() {
        return segurosContratados;
    }

    public void setSegurosContratados(ArrayList<Seguro> segurosContratados) {
        this.segurosContratados = segurosContratados;
    }

    public Boolean getFinalizada() {
        return finalizada;
    }

    public void setFinalizada(Boolean finalizada) {
        this.finalizada = finalizada;
    }
}
