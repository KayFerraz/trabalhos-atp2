package Modelo;

public class VeiculoNacional extends Veiculo {
    private float taxaImpostoEstadual;

    public VeiculoNacional(
        float taxaImpostoEstadual,
        int codigoVeiculo,
        String nomeModelo,
        String montadora,
        int anoFabricacao,
        int anoModelo,
        String placa,
        String categoria,
        float valorFipe,
        float valorDiaria,
        String categoriaCNHNecessaria,
        Boolean alugado
    ) {
        super(codigoVeiculo, nomeModelo, montadora, anoFabricacao, anoModelo, placa, categoria, valorFipe, valorDiaria, categoriaCNHNecessaria, alugado);
        this.taxaImpostoEstadual = taxaImpostoEstadual;
    }

    @Override
    public float calcularValorDiaria() {
        return this.valorDiaria + (this.valorDiaria * this.taxaImpostoEstadual);
    }

    @Override
    public String toString(){
        String dados = "VEÍCULO NACIONAL"
                + super.toString()
                + "\nTaxa Estadual: " + this.taxaImpostoEstadual + "\n\n";
        return dados;
    }

    public float getTaxaImpostoEstadual() {
        return taxaImpostoEstadual;
    }

    public void setTaxaImpostoEstadual(float taxaImpostoEstadual) {
        this.taxaImpostoEstadual = taxaImpostoEstadual;
    }
}
