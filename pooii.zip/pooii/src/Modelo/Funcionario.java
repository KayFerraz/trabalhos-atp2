package Modelo;

import java.time.LocalDate;

public class Funcionario extends Usuario {
    protected float salario;
    protected String pis;
    protected LocalDate dataAdmissao;

    public Funcionario() {
    }

    public Funcionario(
        float Salario,
        String pis,
        LocalDate dataAdmissao,
        int codigoUsuario,
        String nome,
        String cpf,
        String rg,
        String endereco,
        String cep,
        String email,
        LocalDate dataNascimento
    ) {
        super(codigoUsuario, nome, cpf, rg, dataNascimento, endereco, cep, email);
        this.salario = Salario;
        this.pis = pis;
        this.dataAdmissao = dataAdmissao;
    }

    @Override
    public String toString() {
        String dados = "FUNCIONÁRIO"
            + super.toString()
            + "\nSalário: " + this.salario
            + "\nPIS: " + this.pis
            + "\nData de Admissão: " + this.dataAdmissao + "\n\n";
        return dados;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float Salario) {
        this.salario = Salario;
    }

    public String getPis() {
        return pis;
    }

    public void setPis(String pis) {
        this.pis = pis;
    }

    public LocalDate getDataAdmissao() {
        return dataAdmissao;
    }

    public void setDataAdmissao(LocalDate dataAdmissao) {
        this.dataAdmissao = dataAdmissao;
    }

    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
