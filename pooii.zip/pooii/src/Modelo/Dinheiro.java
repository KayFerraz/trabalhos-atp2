package Modelo;

import java.io.Serializable;

public class Dinheiro extends Pagamento {
    private int quantidadeDeCedulas;

    public Dinheiro(int quantidadeDeCedulas, String tipoPagamento) {
        super(tipoPagamento);
        this.quantidadeDeCedulas = quantidadeDeCedulas;
    }

    @Override
    public String toString() {
        return "\nDINHEIRO"
            + "\nTipo de Pagamento: "
            + this.getTipoPagamento()
            + "\nQuantidade de Cédulas: "
            + this.quantidadeDeCedulas;
    }

    public int getQuantidadeDeCedulas() {
        return quantidadeDeCedulas;
    }

    public void setQuantidadeDeCedulas(int quantidadeDeCedulas) {
        this.quantidadeDeCedulas = quantidadeDeCedulas;
    }
}
