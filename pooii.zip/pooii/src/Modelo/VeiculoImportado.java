package Modelo;

public class VeiculoImportado extends Veiculo {
    private float taxaImpostoEstadual;
    private float taxaImpostoFederal;

    public VeiculoImportado(
        float taxaImpostoEstadual,
        float taxaImpostoFederal,
        int codigoVeiculo,
        String nomeModelo,
        String montadora,
        int anoFabricacao,
        int anoModelo,
        String placa,
        String categoria,
        float valorFipe,
        float valorDiaria,
        String categoriaCNHNecessaria,
        Boolean alugado
    ) {
        super(codigoVeiculo, nomeModelo, montadora, anoFabricacao, anoModelo, placa, categoria, valorFipe, valorDiaria, categoriaCNHNecessaria, alugado);
        this.taxaImpostoEstadual = taxaImpostoEstadual;
        this.taxaImpostoFederal = taxaImpostoFederal;
    }

    @Override
    public float calcularValorDiaria() {
        return this.valorDiaria + (this.valorDiaria * this.taxaImpostoEstadual) + (this.valorDiaria * this.taxaImpostoFederal);
    }
    
    @Override
    public String toString(){
        String dados = "VEÍCULO IMPORTADO"
                + super.toString()
                + "\nTaxa Estadual: " + this.taxaImpostoEstadual
                + "\nTaxa Federal: " + this.taxaImpostoFederal + "\n\n";
        return dados;
    }

    public float getTaxaImpostoEstadual() {
        return taxaImpostoEstadual;
    }

    public void setTaxaImpostoEstadual(float taxaImpostoEstadual) {
        this.taxaImpostoEstadual = taxaImpostoEstadual;
    }

    public float getTaxaImpostoFederal() {
        return taxaImpostoFederal;
    }

    public void setTaxaImpostoFederal(float taxaImpostoFederal) {
        this.taxaImpostoFederal = taxaImpostoFederal;
    }
}
