package Modelo;

public class Cartao extends Pagamento {
    private String nome;
    private String bandeira;
    private String numero;
    private int ccv;

    public Cartao(String nome, String bandeira, String numero, int ccv, String tipoPagamento) {
        super(tipoPagamento);
        this.nome = nome;
        this.bandeira = bandeira;
        this.numero = numero;
        this.ccv = ccv;
    }

    @Override
    public String toString() {
        return "\nCARTÃO"
            + "\nTipo de Pagamento: "
            + this.getTipoPagamento()
            + "\nNome: "
            + this.nome
            + "\nBandeira: "
            + this.bandeira
            + "\nNúmero: "
            + this.numero
            + "\nCCV: "
            + this.ccv;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getBandeira() {
        return this.bandeira;
    }

    public void setBandeira(String bandeira) {
        this.bandeira = bandeira;
    }

    public String getNumero() {
        return this.numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public int getCcv() {
        return this.ccv;
    }

    public void setCcv(int ccv) {
        this.ccv = ccv;
    }
}
