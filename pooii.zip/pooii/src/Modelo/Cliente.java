package Modelo;

import java.time.LocalDate;

public class Cliente extends Usuario {
    protected String categoriaCNH;
    protected String numeroCNH;
    protected LocalDate validadeCNH;
    protected Boolean clienteOuro;
    
    public Cliente() {
    }

    public Cliente(
        String categoriaCNH,
        String numeroCNH,
        LocalDate validadeCNH,
        Boolean clienteOuro,
        int codigoUsuario,
        String nome,
        String cpf,
        String rg,
        String endereco,
        String cep,
        String email,
        LocalDate dataNascimento
    ) {
        super(codigoUsuario, nome, cpf, rg, dataNascimento, endereco, cep, email);
        this.categoriaCNH = categoriaCNH;
        this.numeroCNH = numeroCNH;
        this.validadeCNH = validadeCNH;
        this.clienteOuro = clienteOuro;
    }
    public String getCategoriaCNH() {
        return categoriaCNH;
    }

    public void setCategoriaCNH(String categoriaCNH) {
        this.categoriaCNH = categoriaCNH;
    }

    public String getNumeroCNH() {
        return numeroCNH;
    }

    public void setNumeroCNH(String numeroCNH) {
        this.numeroCNH = numeroCNH;
    }

    public LocalDate getValidadeCNH() {
        return validadeCNH;
    }

    public void setValidadeCNH(LocalDate validadeCNH) {
        this.validadeCNH = validadeCNH;
    }

    @Override
     public String toString(){
        String dados = "CLIENTE" 
                + super.toString() 
                + "\nCategoria CNH: " + this.categoriaCNH
                + "\nNumero CNH: " + this.numeroCNH
                + "\nValidade CNH: " + this.validadeCNH
                + "\nCliente Ouro: " + this.clienteOuro + "\n\n";
        return dados;
    }
}
