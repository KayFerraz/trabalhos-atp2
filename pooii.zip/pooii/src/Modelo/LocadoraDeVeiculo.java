package Modelo;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class LocadoraDeVeiculo implements Serializable {
    private String nome;
    private String endereco;
    private String website;
    private String redesocial;
    private ArrayList<Locacao> locacoes;
    private ArrayList<Veiculo> veiculos;
    private ArrayList<Cliente> clientes;
    private ArrayList<Funcionario> funcionarios;
    private ArrayList<Seguro> seguros;

    public LocadoraDeVeiculo(
        String nome,
        String endereco,
        String website,
        String redesocial
    ) {
        this.nome = nome;
        this.endereco = endereco;
        this.website = website;
        this.redesocial = redesocial;
        this.locacoes = new ArrayList<>();
        this.veiculos = new ArrayList<>();
        this.clientes = new ArrayList<>();
        this.funcionarios = new ArrayList<>();
        this.seguros = new ArrayList<>();
    }

    public String dadosClientes(){
        String dados = "";
        for(Cliente c : this.clientes){
            dados += c.toString();
        }
        return dados;
    }
    
    public String dadosClienteVeiculo(int codigo){
        String dados = "";
        for(Locacao l : this.locacoes){
            if(l.getCodigoVeiculo().getCodigoVeiculo() == codigo) dados += l.getCodigoCliente().toString();
        }
        return dados;
    }
    
    public String dadosFuncionarios(){
        String dados = "";
        for(Funcionario f : this.funcionarios){
            dados += f.toString();
        }
        return dados;
    }
    
    /*public String dadosFuncionariosMes(){
        String dados = "JANEIRO";
        int count[] = new int[12];
        for(Locacao l : this.locacoes){
            if(l.getDataLocacao().getMonthValue() == 01){
                if(l.getCodigoFuncionario().get)
            }
        }
        return dados;
    }*/
    
    public String dadosSeguros(){
        String dados = "";
        for(Seguro v : this.seguros){
            dados += v.toString();
        }
        return dados;
    }
    
    public String dadosVeiculosNacionais(){
        String dados = "";
        for(Veiculo v : this.veiculos){
            if(v instanceof VeiculoNacional) dados += v.toString();
        }
        return dados;
    }
    
    public String dadosVeiculosImportados(){
        String dados = "";
        for(Veiculo v : this.veiculos){
            if(v instanceof VeiculoImportado) dados += v.toString();
        }
        return dados;
    }
    
    public String dadosVeiculos(){
        String dados = "";
        for(Veiculo v : this.veiculos){
            dados += v.toString();
        }
        return dados;
    }
    
    public String dadosVeiculosAlugar(){
        String dados = "";
        for(Veiculo v : this.veiculos){
            if(v.getAlugado() == false) dados += v.toString();
        }
        return dados;
    }
    
    public String dadosVeiculosAlugado(){
        String dados = "";
        for(Veiculo v : this.veiculos){
            if(v.getAlugado() == true) dados += v.toString();
        }
        return dados;
    }
    
    public String dadosVeiculosCategoria(String categoria){
        String dados = "";
        for(Veiculo v : this.veiculos){
            if(v.getCategoriaCNHNecessaria().contains(categoria) && v.getAlugado() == false) dados += v.toString();
        }
        return dados;
    }
    
    public String dadosVeiculosAtrasados(){
        String dados = "";
        for(Locacao l : this.locacoes){
            if(l.getDataDevolucao().isBefore(LocalDate.now())) dados += l.getCodigoVeiculo().toString();
        }
        return dados;
    }
    
    public Cliente buscarCliente(int idCliente){
        Cliente cliente = new Cliente();
        for(Cliente c : this.clientes){
            if(c.getCodigoUsuario() == idCliente) cliente = c;
        }
        return cliente;
    }
    
    public Funcionario buscarFuncionario(int idFuncionario){
        Funcionario funcionario = new Funcionario();
        for(Funcionario f : this.funcionarios){
            if(f.getCodigoUsuario() == idFuncionario) funcionario = f;
        }
        return funcionario;
    }
    
    public Veiculo buscarVeiculo(int idVeiculo){
        for(Veiculo v : this.veiculos){
            if(v.getCodigoVeiculo() == idVeiculo) return v;
        }
        return null;
    }
    
    public String dadosLocacoes(){
        String dados = "";
        for(Locacao l : this.locacoes){
            dados += l.toString();
        }
        return dados;
    }
    
    public String dadosLocacoesCliente(String nome){
        String dados = "";
        for(Locacao l : this.locacoes){
            if(l.getCodigoCliente().getNome().contains(nome)) dados += l.toString();
        }
        return dados;
    }
    
    public String dadosClientesAtraso(){
        String dados = "";
        for(Locacao l : this.locacoes){
            if(l.getDataDevolucao().isBefore(LocalDate.now())) dados += l.getCodigoCliente().toString();
        }
        return dados;
    }
    
    public String dadosLocacoesMes(int mes){
        String dados = "";
        float valorTotalMes = 0;
        for(Locacao l : this.locacoes){
            if(l.getDataLocacao().getMonthValue() == mes) valorTotalMes +=l.calcularValorTotal();
        }
        return dados + "\nValor Total no mês: " + valorTotalMes;
    }
    
    public String dadosLocacoesFinalizadas(){
        String dados = "";
        for(Locacao l : this.locacoes){
            if(l.getFinalizada() == true) dados += l.toString();
        }
        return dados;
    }
    
    public String dadosLocacoesNaoFinalizadas(){
        String dados = "";
        for(Locacao l : this.locacoes){  //Não finalizada e data de hoje está antes da data de vencimento (dentro do prazo)
            if(l.getFinalizada() == false && (LocalDate.now().isBefore(l.getDataDevolucao()))) dados += l.toString();
        }
        return dados;
    }
    
    public String dadosLocacoesNaoFinalizadasNacional(){
        String dados = "";
        for(Locacao l : this.locacoes){  //Não finalizada, dentro do prazo e instância de Veiculo Nacional
            if(l.getFinalizada() == false && (LocalDate.now().isBefore(l.getDataDevolucao())) && (l.getCodigoVeiculo() instanceof VeiculoNacional)) dados += l.toString();
        }
        return dados;
    }
    
    public String dadosLocacoesNaoFinalizadasImportado(){
        String dados = "";
        for(Locacao l : this.locacoes){  //Não finalizada, dentro do prazo e instância de Veiculo Importado
            if(l.getFinalizada() == false && (LocalDate.now().isBefore(l.getDataDevolucao())) && (l.getCodigoVeiculo() instanceof VeiculoImportado)) dados += l.toString();
        }
        return dados;
    }
    
    public String dadosLocacoesAtrasadas(){
        String dados = "";
        for(Locacao l : this.locacoes){  //Não finalizada e data de devolução está antes da data de hoje (devolução ja passou, fora do prazo)
            if(l.getFinalizada() == false && (l.getDataDevolucao().isBefore(LocalDate.now()))) dados += l.toString();
        }
        return dados;
    }
    
    public String dadosTiposSeguros(){
        String dados = "";
        for(Locacao l : this.locacoes){
            for(Seguro s : l.getSegurosContratados()) dados += s.getTipo();
        }
        return dados;
    }

    public Seguro buscarSeguro(int idSeguro){
        for(Seguro v : this.seguros){
            if(v.getCodigoSeguro() == idSeguro) return v;
        }
        return null;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return this.endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getWebsite() {
        return this.website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getRedesocial() {
        return this.redesocial;
    }

    public void setRedesocial(String redesocial) {
        this.redesocial = redesocial;
    }

    public ArrayList<Locacao> getLocacoes() {
        return this.locacoes;
    }

    public void setLocacoes(ArrayList<Locacao> locacoes) {
        this.locacoes = locacoes;
    }

    public ArrayList<Veiculo> getVeiculos() {
        return this.veiculos;
    }

    public void setVeiculos(ArrayList<Veiculo> veiculos) {
        this.veiculos = veiculos;
    }

    public ArrayList<Cliente> getClientes() {
        return this.clientes;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    public ArrayList<Funcionario> getFuncionarios() {
        return this.funcionarios;
    }

    public void setFuncionarios(ArrayList<Funcionario> funcionarios) {
        this.funcionarios = funcionarios;
    }

    public ArrayList<Seguro> getSeguros() {
        return this.seguros;
    }

    public void setSeguros(ArrayList<Seguro> seguros) {
        this.seguros = seguros;
    }

   }
