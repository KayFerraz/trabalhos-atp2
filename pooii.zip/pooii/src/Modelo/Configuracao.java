package Modelo;

import java.io.Serializable;

public class Configuracao implements Serializable {
    private String arquivoLocacoes;
    private String arquivoVeiculos;
    private String arquivoCliente;
    private String arquivoSeguro;
    private String arquivoFuncionario;
    private String arquivoPagamento;
    private String arquivoLocacao;
    private String arquivoDinheiro;
    private String arquivoCartao;
    private String arquivoUsuario;

    public Configuracao(
        String arquivoLocacoes,
        String arquivoVeiculos,
        String arquivoCliente,
        String arquivoSeguro,
        String arquivoFuncionario,
        String arquivoPagamento,
        String arquivoLocacao,
        String arquivoDinheiro,
        String arquivoCartao,
        String arquivoUsuario
    ) {
        this.arquivoLocacoes = arquivoLocacoes;
        this.arquivoVeiculos = arquivoVeiculos;
        this.arquivoCliente = arquivoCliente;
        this.arquivoSeguro = arquivoSeguro;
        this.arquivoFuncionario = arquivoFuncionario;
        this.arquivoPagamento = arquivoPagamento;
        this.arquivoLocacao = arquivoLocacao;
        this.arquivoDinheiro = arquivoDinheiro;
        this.arquivoCartao = arquivoCartao;
        this.arquivoUsuario = arquivoUsuario;
    }

    public String getArquivoLocacoes() {
        return arquivoLocacoes;
    }

    public void setArquivoLocacoes(String arquivoLocacoes) {
        this.arquivoLocacoes = arquivoLocacoes;
    }

    public String getArquivoVeiculos() {
        return arquivoVeiculos;
    }

    public void setArquivoVeiculos(String arquivoVeiculos) {
        this.arquivoVeiculos = arquivoVeiculos;
    }

    public String getArquivoCliente() {
        return arquivoCliente;
    }

    public void setArquivoCliente(String arquivoCliente) {
        this.arquivoCliente = arquivoCliente;
    }

    public String getArquivoSeguro() {
        return arquivoSeguro;
    }

    public void setArquivoSeguro(String arquivoSeguro) {
        this.arquivoSeguro = arquivoSeguro;
    }

    public String getArquivoFuncionario() {
        return arquivoFuncionario;
    }

    public void setArquivoFuncionario(String arquivoFuncionario) {
        this.arquivoFuncionario = arquivoFuncionario;
    }

    public String getArquivoPagamento() {
        return arquivoPagamento;
    }

    public void setArquivoPagamento(String arquivoPagamento) {
        this.arquivoPagamento = arquivoPagamento;
    }

    public String getArquivoLocacao() {
        return arquivoLocacao;
    }

    public void setArquivoLocacao(String arquivoLocacao) {
        this.arquivoLocacao = arquivoLocacao;
    }

    public String getArquivoDinheiro() {
        return arquivoDinheiro;
    }

    public void setArquivoDinheiro(String arquivoDinheiro) {
        this.arquivoDinheiro = arquivoDinheiro;
    }

    public String getArquivoCartao() {
        return arquivoCartao;
    }

    public void setArquivoCartao(String arquivoCartao) {
        this.arquivoCartao = arquivoCartao;
    }

    public String getArquivoUsuario() {
        return arquivoUsuario;
    }

    public void setArquivoUsuario(String arquivoUsuario) {
        this.arquivoUsuario = arquivoUsuario;
    }
}
