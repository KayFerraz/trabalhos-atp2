#include <stdio.h>
#include <string.h>

int verif (char [], char []);

int main (){
    char a[200], b[200];
    int pos;

    printf("digite sua frase aqui:\n");
    gets(a);

    printf("digite a string a ser procurada:\n");
    gets(b);

    pos = verif(a,b);

    if (pos != -1){
        printf("encontrado na posicao: %d", pos + 1);
    } else {
    printf("nao encontrado");
    }
    return 0;
}

int verif (char text [], char pattern []) {
int c, d, e, text_comp, pattern_comp, posicao = -1;

text_comp = strlen(text);
pattern_comp = strlen(pattern);

    if (pattern_comp > text_comp){
        return -1;
    }

        for (c = 0; c <= text_comp - pattern_comp; c++){
            posicao = e = c;
           for (d = 0; d < pattern_comp; d++){
            if (pattern[d] == text[e]){
                e++;
            }
            else {
                break;
            }
           }
           if (d == pattern_comp){
            return posicao;
           }
        }
return -1;
}

